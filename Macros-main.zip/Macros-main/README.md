my-project/
├── index.html
├── app.css
└── app.js
