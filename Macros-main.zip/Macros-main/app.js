document.addEventListener('DOMContentLoaded', () => {
    // Referências aos elementos
    const macrosSection = document.getElementById('macrosSection');
    const databaseSection = document.getElementById('databaseSection');
    const showMacrosButton = document.getElementById('showMacros');
    const showDatabaseButton = document.getElementById('showDatabase');
    const macroList = document.getElementById('macroList');
    const dataInput = document.getElementById('dataInput');
    const dataTag = document.getElementById('dataTag');
    const addDataButton = document.getElementById('addData');
    const dataList = document.getElementById('dataList');
    const macroTagFilterSelect = document.getElementById('macroTagFilterSelect');
    const applyMacroFilterButton = document.getElementById('applyMacroFilter');

    let databaseItems = [];

    // Exibir a seção de Macros
    showMacrosButton.addEventListener('click', () => {
        macrosSection.classList.remove('hidden');
        databaseSection.classList.add('hidden');
    });

    // Exibir a seção de Base de Dados
    showDatabaseButton.addEventListener('click', () => {
        macrosSection.classList.add('hidden');
        databaseSection.classList.remove('hidden');
    });

    // Adicionar item à base de dados
    addDataButton.addEventListener('click', () => {
        const dataText = dataInput.value.trim();
        const dataTagText = dataTag.value.trim();
        
        if (!dataText) {
            alert('Erro: O texto não pode estar vazio.');
            return;
        }
        
        if (!dataTagText) {
            alert('Erro: A tag não pode estar vazia.');
            return;
        }

        const item = { text: dataText, tag: dataTagText };
        databaseItems.push(item);
        updateDataList();
        updateMacroTagFilterSelect(); // Atualiza as opções do filtro na seção de macros
        dataInput.value = '';
        dataTag.value = '';
    });

    // Aplicar filtro na lista de macros
    applyMacroFilterButton.addEventListener('click', () => {
        updateMacroList();
    });

    // Atualizar lista de dados na interface
    function updateDataList() {
        // Classificar por tag antes de atualizar a lista
        databaseItems.sort((a, b) => a.tag.localeCompare(b.tag));

        dataList.innerHTML = '';
        databaseItems.forEach((item, index) => {
            const dataItem = document.createElement('li');
            dataItem.innerHTML = `${item.text} [Tag: ${item.tag}] 
                <button onclick="deleteItem(${index})">🗑️</button>`;
            dataList.appendChild(dataItem);
        });
    }

    // Função para excluir um item da base de dados
    window.deleteItem = function(index) {
        databaseItems.splice(index, 1);
        updateDataList();
        updateMacroTagFilterSelect(); // Atualiza as opções do filtro na seção de macros
    };

    // Atualizar lista de macros com os itens da base de dados
    function updateMacroList() {
        const selectedTag = macroTagFilterSelect.value;
        const filteredItems = databaseItems
            .filter(item => item.tag === selectedTag);

        // Classificar por tag antes de atualizar a lista de macros
        filteredItems.sort((a, b) => a.tag.localeCompare(b.tag));

        macroList.innerHTML = '';
        filteredItems.forEach(item => {
            const macroItem = document.createElement('div');
            macroItem.textContent = `${item.text} [Tag: ${item.tag}]`;

            // Criar botão "Copiar"
            const copyButton = document.createElement('button');
            copyButton.textContent = 'Copiar';
            copyButton.addEventListener('click', () => {
                copyToClipboard(item.text);
            });

            // Adicionar o botão ao item
            macroItem.appendChild(copyButton);
            macroList.appendChild(macroItem);
        });
    }

    // Função para copiar texto para a área de transferência
    function copyToClipboard(text) {
        const tempInput = document.createElement('input');
        document.body.appendChild(tempInput);
        tempInput.value = text;
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        alert('Texto copiado para a área de transferência!');
    }

    // Atualizar as opções do filtro na seção de macros
    function updateMacroTagFilterSelect() {
        // Extrair tags únicas da lista de itens da base de dados
        const tags = [...new Set(databaseItems.map(item => item.tag))];

        // Limpar o menu suspenso
        macroTagFilterSelect.innerHTML = '<option value="">Selecione uma tag</option>';

        // Adicionar opções ao menu suspenso
        tags.sort().forEach(tag => {
            const option = document.createElement('option');
            option.value = tag;
            option.textContent = tag;
            macroTagFilterSelect.appendChild(option);
        });
    }
});
